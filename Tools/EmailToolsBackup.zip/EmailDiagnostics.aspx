<%@ Page Language="C#" AutoEventWireup="true" MasterPageFile="~/Site.Master" MaintainScrollPositionOnPostback="true" CodeBehind="EmailDiagnostics.aspx.cs" Inherits="TrackerSQL.Tools.EmailDiagnostics" %>

<%@ Register Assembly="AjaxControlToolkit" Namespace="AjaxControlToolkit" TagPrefix="ajax" %>

<asp:Content ID="cntEmailTestHdr" ContentPlaceHolderID="HeadContent" runat="server">
    <title>QonT Email Configuration Tester</title>
    <link rel="stylesheet" type="text/css" href="./EmailDiagnostics.css" />
    <style type="text/css">
        .auto-style1 {
            width: 32px;
            height: 32px;
        }
    </style>
</asp:Content>
<asp:Content ID="cntSendCoffeeCheckupBdy" ContentPlaceHolderID="MainContent" runat="server">
    <%--<form id="form1" runat="server">--%>
    <asp:ScriptManager ID="scrmngEmailTest" runat="server" />
    <asp:Label ID="lblGlobalStatus" runat="server" ForeColor="Blue" />

    <div class="container">
        <h2 class="test-h2">Email Configuration Tester</h2>
        
        <ajax:TabContainer ID="TabContainer1" runat="server" ActiveTabIndex="0" CssClass="ajax-tabs">

            <!-- Email Test Tab -->
            <ajax:TabPanel ID="TabEmail" runat="server" HeaderText="Test Email">
                <ContentTemplate>
                    <asp:UpdateProgress ID="uprgEmailTest" runat="server" AssociatedUpdatePanelID="upGlobal">
                        <ProgressTemplate>
                            <div class="update-progress">
                                <img alt="progress" class="auto-style1" src="../images/animi/img_progress.gif" height="16" />Sending...
                            </div>
                        </ProgressTemplate>
                    </asp:UpdateProgress>
                    <asp:UpdatePanel ID="upGlobal" runat="server" UpdateMode="Conditional">
                        <ContentTemplate>
                            <div class="test-css">
                                <fieldset>
                                    <legend>SMTP Settings</legend>

                                    <label for="<%= txtHost.ClientID %>">SMTP Host:</label>
                                    <asp:TextBox ID="txtHost" runat="server"
                                        title="Enter your SMTP server's hostname"
                                        placeholder="smtp.yourdomain.com" />

                                    <label for="<%= txtPort.ClientID %>">Port:</label>
                                    <asp:TextBox ID="txtPort" runat="server"
                                        title="Enter the SMTP port number"
                                        placeholder="465" />

                                    <label for="<%= txtUser.ClientID %>">Username:</label>
                                    <asp:TextBox ID="txtUser" runat="server"
                                        title="Enter your SMTP username"
                                        placeholder="user@example.com" />

                                    <div class="password-group">
                                        <label for="<%= txtPass.ClientID %>">Password:</label>
                                        <div class="input-with-toggle">
                                            <asp:TextBox ID="txtPass" runat="server" TextMode="Password"
                                                title="Enter your password"
                                                placeholder="��������" />

                                            <div class="checkbox-label">
                                                <asp:CheckBox ID="chkShowPwd" runat="server"
                                                    AutoPostBack="true"
                                                    OnCheckedChanged="chkShowPwd_CheckedChanged" />
                                                <label for="<%= chkShowPwd.ClientID %>">Show password</label>
                                            </div>
                                        </div>
                                    </div>

                                    <label for="<%= chkSSL.ClientID %>">Enable SSL:</label>
                                    <asp:CheckBox ID="chkSSL" runat="server"
                                        title="Check if SSL should be used when connecting" />

                                    <label for="<%= ddlSocketOption.ClientID %>">Secure Socket Option:</label>
                                    <asp:DropDownList ID="ddlSocketOption" runat="server"
                                        title="Select the appropriate secure socket method">
                                        <asp:ListItem Text="Auto" Value="Auto" />
                                        <asp:ListItem Text="None" Value="None" />
                                        <asp:ListItem Text="SSL on Connect" Value="SslOnConnect" />
                                        <asp:ListItem Text="StartTLS" Value="StartTls" />
                                    </asp:DropDownList>

                                    <label for="<%= txtTimeout.ClientID %>">Timeout (ms):</label>
                                    <asp:TextBox ID="txtTimeout" runat="server" Text="10000"
                                        title="Enter the connection timeout in milliseconds"
                                        placeholder="10000" />
                                </fieldset>

                                <fieldset>
                                    <legend>Email Details</legend>

                                    <label for="<%= txtFrom.ClientID %>">From Address:</label>
                                    <asp:TextBox ID="txtFrom" runat="server"
                                        title="Enter the sender's email address"
                                        placeholder="sender@domain.com" />

                                    <label for="<%= txtTo.ClientID %>">To Address:</label>
                                    <asp:TextBox ID="txtTo" runat="server"
                                        title="Enter the recipient's email address"
                                        placeholder="recipient@domain.com" />

                                    <label for="<%= txtSubject.ClientID %>">Subject:</label>
                                    <asp:TextBox ID="txtSubject" runat="server"
                                        title="Enter the email subject"
                                        placeholder="Test Subject" />

                                    <label for="<%= txtBody.ClientID %>">Body:</label>
                                    <asp:TextBox ID="txtBody" runat="server" TextMode="MultiLine" Rows="5"
                                        title="Enter the body of the email"
                                        placeholder="This is a test message..." />
                                </fieldset>

                                <div class="form-actions">
                                    <asp:Button ID="btnSend" runat="server" Text="Send Test Email" OnClick="btnSend_Click" />
                                    <asp:Button ID="btnSaveConfig" runat="server" Text="Save to Web.Config" OnClick="btnSaveConfig_Click" />
                                </div>

                                <div class="result-output">
                                    <asp:Literal ID="litResult" runat="server" Mode="PassThrough" />
                                </div>
                            </div>

                        </ContentTemplate>
                    </asp:UpdatePanel>
                </ContentTemplate>
            </ajax:TabPanel>

            <!-- Diagnostics Tab -->
            <ajax:TabPanel ID="TabDiag" runat="server" HeaderText="Diagnostics">
                <ContentTemplate>
                    <asp:UpdateProgress ID="uprgEmailDiag" runat="server" AssociatedUpdatePanelID="upDiag">
                        <ProgressTemplate>
                            <img src="../images/animi/img_progress.gif" alt="Testing..." width="16" height="16" />Testing...
                        </ProgressTemplate>
                    </asp:UpdateProgress>
                    <asp:UpdatePanel ID="upDiag" runat="server" UpdateMode="Conditional" ChildrenAsTriggers="true">
                        <Triggers>
                            <asp:AsyncPostBackTrigger ControlID="btnDiagnostics" EventName="Click" />
                            <asp:AsyncPostBackTrigger ControlID="btnViewLog" EventName="Click" />
                        </Triggers>
                        <ContentTemplate>
                            <div class="test-css">

                                <fieldset>
                                    <legend>SMTP Diagnostics</legend>
                                    <asp:Button ID="btnDiagnostics" runat="server" Text="Run SMTP Diagnostics" OnClick="btnDiagnostics_Click" />
                                    <div class="diagnostics-output">
                                        <asp:Literal ID="litDiagnostics" runat="server" Mode="PassThrough" />
                                    </div>
                                </fieldset>

                                <fieldset>
                                    <legend>Diagnostics Log Viewer</legend>
                                    <asp:Button ID="btnViewLog" runat="server" Text="View Log File" OnClick="btnViewLog_Click" />
                                    <asp:Literal ID="litLogOutput" runat="server" Mode="PassThrough" />
                                </fieldset>

                                <fieldset>
                                    <legend>Log Utilities</legend>
                                    <asp:Button ID="btnClearCombosLog" runat="server" Text="Clear Combos Log" OnClick="btnClearCombosLog_Click" />
                                    <asp:Label ID="lblClearLogStatus" runat="server" />
                                    <asp:HyperLink ID="lnkDownloadLog" runat="server" Text="Download Log File" NavigateUrl="~/App_Data/smtp_combos.log" Target="_blank" />
                                </fieldset>

                                <fieldset>
                                    <legend>Test All SMTP Combos</legend>
                                    <button type="button" id="btnTestCombosClient" class="combo-test-btn">Test All Combos</button>
                                    <asp:HiddenField ID="hfProgressKey" runat="server" />
                                </fieldset>
                            </div>
                        </ContentTemplate>
                    </asp:UpdatePanel>
                </ContentTemplate>
            </ajax:TabPanel>

        </ajax:TabContainer>

        <div id="comboTestPanel" class="combo-test-panel">
            <div id="spinner" class="combo-spinner" style="display: none;">
                <img src="../images/animi/img_progress.gif" alt="Working" width="16" height="16" />
                Testing combinations...
            </div>
            <div id="progressStatus">Progress: 0%</div>
            <div id="comboResults"></div>
        </div>
    </div>

    <script type="text/javascript">
        var comboTestHandlerUrl = '<%= ResolveUrl("~/Tools/EmailComboTest.ashx") %>';
        var diagIconBase = '<%= ResolveUrl("~/images/imgButtons/") %>';
        function showSpinner() {
            var spinner = document.getElementById("spinner");
            if (spinner) spinner.style.display = "block";
        }

        function hideSpinner() {
            var spinner = document.getElementById("spinner");
            if (spinner) spinner.style.display = "none";
        }

        function setProgressStatus(text) {
            var el = document.getElementById("progressStatus");
            if (el) el.innerHTML = text;
        }

        function postComboAction(params, onSuccess, onError) {
            var body = new URLSearchParams();
            for (var name in params) {
                if (Object.prototype.hasOwnProperty.call(params, name)) {
                    body.append(name, params[name]);
                }
            }

            fetch(comboTestHandlerUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                body: body.toString(),
                credentials: 'same-origin'
            })
                .then(function (response) {
                    return response.text().then(function (text) {
                        if (!response.ok) {
                            throw new Error(text || response.statusText);
                        }
                        return JSON.parse(text);
                    });
                })
                .then(onSuccess)
                .catch(function (err) { onError(err.message || String(err)); });
        }

        function startComboTest() {
            var btn = document.getElementById('btnTestCombosClient');
            var smtpHost = document.getElementById('<%= txtHost.ClientID %>').value;
            var smtpUser = document.getElementById('<%= txtUser.ClientID %>').value;
            var smtpPass = document.getElementById('<%= txtPass.ClientID %>').value;
            var fromAddress = document.getElementById('<%= txtFrom.ClientID %>').value;
            var toAddress = document.getElementById('<%= txtTo.ClientID %>').value;

            if (!smtpHost || !smtpUser) {
                alert('Enter SMTP host and username on the Test Email tab first.');
                return;
            }

            btn.disabled = true;
            btn.style.opacity = "0.6";
            btn.style.cursor = "not-allowed";
            showSpinner();
            setProgressStatus('<img src="../images/animi/img_progress.gif" alt="" width="16" height="16" class="diag-icon" /> Testing combinations (may take up to a minute)...');
            document.getElementById("comboResults").innerHTML = "";

            postComboAction({
                action: 'start',
                smtpHost: smtpHost,
                smtpUser: smtpUser,
                smtpPass: smtpPass,
                from: fromAddress,
                to: toAddress
            },
                function (result) {
                    btn.disabled = false;
                    btn.style.opacity = "1";
                    btn.style.cursor = "pointer";
                    hideSpinner();

                    if (!result || result.status === 'error') {
                        setProgressStatus((result && result.message) ? result.message : 'Combo test failed.');
                        return;
                    }

                    setProgressStatus('Progress: 100% (' + result.completedCount + '/' + result.total + ')');
                    document.getElementById("comboResults").innerHTML = result.html || '';
                },
                function (msg) {
                    setProgressStatus('Error running combo test: ' + msg);
                    btn.disabled = false;
                    btn.style.opacity = "1";
                    btn.style.cursor = "pointer";
                    hideSpinner();
                });
        }

        function applyCombo(port, option) {
            document.getElementById('<%= txtPort.ClientID %>').value = port;
            document.getElementById('<%= ddlSocketOption.ClientID %>').value = option;
            setProgressStatus('<img src="' + diagIconBase + 'Yes.png" alt="" class="diag-icon" /> Applied: Port ' + port + ', Option ' + option);
        }

        document.addEventListener('DOMContentLoaded', function () {
            var btn = document.getElementById('btnTestCombosClient');
            if (btn) {
                btn.addEventListener('click', startComboTest);
            }
        });
    </script>
    <%--</form>--%>
</asp:Content>
