using System;
using System.Configuration;
using System.IO;
using System.Web.UI;
using System.Web.UI.WebControls;
using TrackerSQL.Classes;

namespace TrackerSQL.Tools
{
    public partial class EmailDiagnostics : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                var config = ConfigurationManager.AppSettings;

                txtHost.Text = config["EMailSMTP"] ?? "";
                txtPort.Text = config["EMailPort"] ?? "";
                txtUser.Text = config["EMailLogIn"] ?? "";
                txtPass.Text = config["EmailPassword"] ?? "";
                txtFrom.Text = config["SysEmailFrom"] ?? "";

                chkSSL.Checked = (config["EMailSSLEnabled"] ?? "false").ToLower() == "true";
                ddlSocketOption.SelectedValue = config["EmailSocketOption"] ?? "Auto";
                txtTimeout.Text = config["EmailTimeout"] ?? "10000";
            }

            txtPass.Attributes["value"] = txtPass.Text;
        }

        protected void chkShowPwd_CheckedChanged(object sender, EventArgs e)
        {
            txtPass.TextMode = chkShowPwd.Checked ? TextBoxMode.SingleLine : TextBoxMode.Password;
            txtPass.Attributes["value"] = txtPass.Text;
        }

        private EmailSettings GetEmailSettings()
        {
            return new EmailSettings(
                txtHost.Text.Trim(),
                int.TryParse(txtPort.Text, out var p) ? p : 25,
                txtUser.Text.Trim(),
                txtPass.Text,
                chkSSL.Checked,
                ddlSocketOption.SelectedValue,
                int.TryParse(txtTimeout.Text, out var t) ? t : 10000,
                txtFrom.Text.Trim(),
                txtTo.Text.Trim(),
                null
            );
        }

        protected void btnSend_Click(object sender, EventArgs e)
        {
            lblGlobalStatus.Text = "";
            litResult.Text = "";
            upGlobal.Update();

            lblGlobalStatus.Text = "Sending test email...";

            var emailSettings = GetEmailSettings();
            var email = new EmailMailKitCls(emailSettings);

            if (!email.SetEmailFromTo(txtFrom.Text, txtTo.Text))
            {
                litResult.Text = DiagnosticsIconHelper.Error + " Invalid email addresses.";
                return;
            }

            email.SetEmailSubject(txtSubject.Text);
            email.AddToBody(txtBody.Text);

            bool success = email.SendEmail();
            litResult.Text = email.GetFormattedResultMessage(success);
            lblGlobalStatus.Text = "Test email completed.";
        }

        void SetOrAdd(KeyValueConfigurationCollection settings, string key, string value)
        {
            if (settings[key] == null)
                settings.Add(key, value);
            else
                settings[key].Value = value;
        }

        protected void btnSaveConfig_Click(object sender, EventArgs e)
        {
            try
            {
                var settingsObj = GetEmailSettings();
                var config = System.Web.Configuration.WebConfigurationManager.OpenWebConfiguration(Request.ApplicationPath);
                var appSettings = config.AppSettings.Settings;

                SetOrAdd(appSettings, "EMailSMTP", settingsObj.SmtpHost);
                SetOrAdd(appSettings, "EMailPort", settingsObj.SmtpPort.ToString());
                SetOrAdd(appSettings, "EMailLogIn", settingsObj.SmtpUser);
                SetOrAdd(appSettings, "EmailPassword", settingsObj.SmtpPass);
                SetOrAdd(appSettings, "EMailSSLEnabled", settingsObj.EnableSSL.ToString().ToLower());
                SetOrAdd(appSettings, "EmailSocketOption", settingsObj.SocketOption);
                SetOrAdd(appSettings, "EmailTimeout", settingsObj.Timeout.ToString());
                SetOrAdd(appSettings, "SysEmailFrom", settingsObj.FromAddress);

                config.Save();
                litResult.Text = DiagnosticsIconHelper.Success + " Settings saved to web.config.";
            }
            catch (Exception ex)
            {
                litResult.Text = DiagnosticsIconHelper.Error + " Failed to save: " + Server.HtmlEncode(ex.Message);
            }
        }

        protected void btnDiagnostics_Click(object sender, EventArgs e)
        {
            lblGlobalStatus.Text = "Running Diagnostics...";
            var emailSettings = GetEmailSettings();
            var email = new EmailMailKitCls(emailSettings);
            string result = email.GetServerDiagnostics();

            litDiagnostics.Text = DiagnosticsIconHelper.FormatDiagnosticsHtml(result);
            lblGlobalStatus.Text = "Diagnostics complete.";
            upDiag.Update();
        }

        protected void btnViewLog_Click(object sender, EventArgs e)
        {
            lblGlobalStatus.Text = "View Log click...";
            string logPath = Server.MapPath("~/App_Data/smtp_diagnostics.log");

            if (!File.Exists(logPath))
            {
                litLogOutput.Text = "<div class='error'>" + DiagnosticsIconHelper.Warning + " Log file not found.</div>";
                return;
            }

            string[] lines = File.ReadAllLines(logPath);
            var html = new System.Text.StringBuilder();
            html.Append("<div style='font-family: monospace; max-height: 400px; overflow-y: auto; background: #f9f9f9; border: 1px solid #ccc; padding: 10px;'>");

            foreach (string line in lines)
            {
                html.Append(System.Web.HttpUtility.HtmlEncode(line) + "<br />");
            }

            html.Append("</div>");
            litLogOutput.Text = html.ToString();
            lblGlobalStatus.Text = "View Log click done...";
        }

        protected void btnClearCombosLog_Click(object sender, EventArgs e)
        {
            string path = Server.MapPath("~/App_Data/smtp_combos.log");
            try
            {
                if (File.Exists(path))
                {
                    File.WriteAllText(path, "");
                    lblClearLogStatus.Text = DiagnosticsIconHelper.Success + " Log file cleared.";
                }
                else
                {
                    lblClearLogStatus.Text = DiagnosticsIconHelper.Warning + " Log file not found.";
                }
            }
            catch (Exception ex)
            {
                lblClearLogStatus.Text = DiagnosticsIconHelper.Error + " Error clearing log: " + Server.HtmlEncode(ex.Message);
            }
        }
    }
}
