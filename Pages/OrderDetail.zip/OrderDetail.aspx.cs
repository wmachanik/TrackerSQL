﻿// Decompiled with JetBrains decompiler
// Type: TrackerDotNet.Pages.OrderDetail
// Assembly: TrackerDotNet, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 2B5ACBFB-45EE-46B9-81D2-DBD1194F39CE
// Assembly location: C:\SRC\Apps\qtracker\bin\TrackerDotNet.dll

using AjaxControlToolkit;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using TrackerDotNet.Classes;
using TrackerDotNet.Controls;
using TrackerDotNet.Managers;
//- only form later versions #nullable disable
namespace TrackerDotNet.Pages
{
    public partial class OrderDetail : Page
    {
        public const string CONST_EMAILDELIMITERSTART = "[#";
        public const string CONST_EMAILDELIMITEREND = "#]";
        public const string CONST_QRYSTR_CustomerID = "CustomerID";
        public const string CONST_QRYSTR_DELIVERYDATE = "DeliveryDate";
        public const string CONST_QRYSTR_NOTES = "Notes";
        public const string CONST_QRYSTR_DELIVERED = "Delivered";
        public const string CONST_QRYSTR_INVOICED = "Invoiced";
        private const string CONST_FROMEMAIL = "orders@quaffee.co.za";
        private const string CONST_DELIVERYTYPEISCOLLECTION = "Cllct";
        private const string CONST_DELIVERYTYPEISCOURIER = "Cour";
        private const string CONST_ORDERHEADERVALUES = "OrderHeaderValues";
        private const string CONST_ORDERHEADER_CONTACT_ID = "cboContacts";
        private const string CONST_ORDERLINE_ITEM_COMBOBOX_ID = "cboItemDesc";
        private const string CONST_ORDERLINE_ITEM_HIDDENFIELD_LABEL = "lblItemDesc";
        private const string CONST_ORDERLINE_ITEM_HIDDENFIELD_ID = "hdnItemTypeID";
        private const string CONST_ORDERLINE_PACKAGING_COMBOBOX_ID = "cboPackaging";
        private const string CONST_ORDERLINE_PACKAGING_HIDDENFIELD_LABEL = "lblPackaging";
        private const string CONST_ORDERLINE_PACKAGING_HIDDENFIELD_ID = "hdnPackagingID";
        protected ScriptManager scrmOrderDetail;
        protected UpdateProgress udtpOrderDetail;
        protected UpdatePanel pnlOrderHeader;
        protected DetailsView dvOrderHeader;
        protected UpdatePanel upnlOrderLines;
        protected GridView gvOrderLines;
        protected UpdatePanel upnlNewOrderItem;
        protected Button btnNewItem;
        protected Panel pnlNewItem;
        protected TextBox tbxNewQuantityOrdered;
        protected Button btnAdd;
        protected Button btnCancel;
        protected Literal ltrlStatus;
        protected UpdatePanel updtButtonPanel;
        protected Button btnNewOrder;
        protected Button btnConfirmOrder;
        protected Button btnDlSheet;
        protected Button btnOrderCancelled;
        protected Button btnUnDoDone;
        protected Button btnOrderDelivered;
        protected ObjectDataSource odsOrderSummary;
        protected SqlDataSource sdsCompanys;
        protected ObjectDataSource odsOrderDetail;
        protected SqlDataSource sdsDeliveryBy;
        protected ObjectDataSource odsItemTypes;
        protected SqlDataSource sdsPackagingTypes;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                long num = 1;
                DateTime date = TimeZoneUtils.Now().Date;
                string empty = string.Empty;
                if (this.Request.QueryString["CustomerID"] != null)
                    num = (long)Convert.ToInt32(this.Request.QueryString["CustomerID"].ToString());
                if (this.Request.QueryString["DeliveryDate"] != null)
                    date = Convert.ToDateTime(this.Request.QueryString["DeliveryDate"]).Date;
                if (this.Request.QueryString["Notes"] != null)
                    empty = this.Request.QueryString["Notes"].ToString();
                this.Session[SystemConstants.SessionConstants.BoundCustomerID] = (object)num;
                this.Session[SystemConstants.SessionConstants.BoundDeliveryDate] = (object)date.Date;
                this.Session[SystemConstants.SessionConstants.BoundNotes] = (object)empty;
                this.Session[CONST_ORDERHEADERVALUES] = (object)null;
                OrderItemTbl orderItemTbl = new OrderItemTbl();
                this.btnOrderCancelled.Enabled = Membership.GetUser().UserName.ToLower() == SystemConstants.UserConstants.AdminUserName;
                this.btnNewItem.Enabled = this.User.IsInRole("Administrators") || this.User.IsInRole("AgentManager") || this.User.IsInRole("Agents");
                new TrackerTools().SetTrackerSessionErrorString(string.Empty);
                if (this.Request.QueryString["Invoiced"] != null)
                {
                    if (!this.Request.QueryString["Invoiced"].Equals("Y"))
                        return;
                    this.MarkItemAsInvoiced();
                }
                else
                {
                    if (this.Request.QueryString["Delivered"] == null || !this.Request.QueryString["Delivered"].Equals("Y"))
                        return;
                    this.btnOrderDelivered_Click(sender, e);
                }
            }
            else
            {
                TrackerTools trackerTools = new TrackerTools();
                string sessionErrorString = trackerTools.GetTrackerSessionErrorString();
                if (string.IsNullOrEmpty(sessionErrorString))
                    return;
                showMessageBox showMessageBox = new showMessageBox(this.Page, "Tracker Error", "ERROR: " + sessionErrorString);
                trackerTools.SetTrackerSessionErrorString(string.Empty);
            }
        }

        private string GetOrderHeaderRequiredByDateStr()
        {
            string empty = string.Empty;
            return this.dvOrderHeader.CurrentMode != DetailsViewMode.Edit ? this.dvOrderHeaderGetLabelValue("lblRequiredByDate") : this.dvOrderHeaderGetTextBoxValue("tbxRequiredByDate");
        }

        private string GetOrderHeaderNotes()
        {
            string empty = string.Empty;
            return this.dvOrderHeader.CurrentMode != DetailsViewMode.Edit ? this.dvOrderHeaderGetLabelValue("lblNotes") : this.dvOrderHeaderGetTextBoxValue("tbxNotes");
        }

        private void BindRowQueryParameters()
        {
            string controlSelectedValue = this.dvOrderHeaderGetCBoControlSelectedValue(CONST_ORDERHEADER_CONTACT_ID);
            this.Session[SystemConstants.SessionConstants.BoundCustomerID] = (object)Convert.ToInt32(controlSelectedValue);
            DateTime date = Convert.ToDateTime(this.GetOrderHeaderRequiredByDateStr()).Date;
            this.Session[SystemConstants.SessionConstants.BoundDeliveryDate] = (object)date.Date;
            string orderHeaderNotes = this.GetOrderHeaderNotes();
            this.Session[SystemConstants.SessionConstants.BoundNotes] = (object)orderHeaderNotes;
            UriBuilder uriBuilder = new UriBuilder(this.Request.Url);
            NameValueCollection queryString = HttpUtility.ParseQueryString(uriBuilder.Query);
            queryString.Set("CustomerID", controlSelectedValue);
            queryString.Set("DeliveryDate", $"{date:yyyy-MM-dd}");
            queryString.Set("Notes", orderHeaderNotes);
            uriBuilder.Query = queryString.ToString();
            string script = $"ChangeUrl('OrderDetail','{uriBuilder.Uri.ToString()}')";
            System.Web.UI.ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "Order Detail", script, true);
        }

        protected void btnNewItem_Click(object sender, EventArgs e)
        {
            this.btnAdd.Visible = true;
            this.btnCancel.Visible = true;
            this.pnlNewItem.Visible = true;
            this.btnNewItem.Visible = false;
            this.upnlNewOrderItem.Update();
        }

        private void HideNewOrderItemPanel()
        {
            this.btnAdd.Visible = false;
            this.btnCancel.Visible = false;
            this.pnlNewItem.Visible = false;
            this.btnNewItem.Visible = true;
            this.upnlNewOrderItem.Update();
            this.odsOrderDetail.DataBind();
            this.gvOrderLines.DataBind();
            this.upnlOrderLines.Update();
        }

        private string dvOrderHeaderGetDDLControlSelectedValue(string pDDLControlName)
        {
            DropDownList control = (DropDownList)this.dvOrderHeader.FindControl(pDDLControlName);
            return control.SelectedValue == null ? "0" : control.SelectedValue;
        }
        private string dvOrderHeaderGetCBoControlSelectedValue(string comboBoxControlName)
        {
            var coBox = (ComboBox)this.dvOrderHeader.FindControl(comboBoxControlName);
            return coBox.SelectedValue == null ? "0" : coBox.SelectedValue;
        }

        private string dvOrderHeaderGetTextBoxValue(string pTextBoxControlName)
        {
            TextBox control = (TextBox)this.dvOrderHeader.FindControl(pTextBoxControlName);
            return control != null ? control.Text : string.Empty;
        }

        private string dvOrderHeaderGetLabelValue(string pTextBoxControlName)
        {
            Label control = (Label)this.dvOrderHeader.FindControl(pTextBoxControlName);
            return control != null ? control.Text : string.Empty;
        }

        private bool dvOrderHeaderGetCheckBoxValue(string pCheckBoxControlName)
        {
            CheckBox control = (CheckBox)this.dvOrderHeader.FindControl(pCheckBoxControlName);
            return control != null && control.Checked;
        }

        private OrderHeaderData Get_dvOrderHeaderData(bool pInEditMode)
        {
            OrderHeaderData dvOrderHeaderData = new OrderHeaderData();
            dvOrderHeaderData.CustomerID = Convert.ToInt32(this.dvOrderHeaderGetCBoControlSelectedValue(CONST_ORDERHEADER_CONTACT_ID));
            dvOrderHeaderData.ToBeDeliveredBy = Convert.ToInt32(this.dvOrderHeaderGetDDLControlSelectedValue("ddlToBeDeliveredBy"));
            dvOrderHeaderData.Confirmed = this.dvOrderHeaderGetCheckBoxValue("cbxConfirmed");
            dvOrderHeaderData.Done = this.dvOrderHeaderGetCheckBoxValue("cbxDone");
            string empty1 = string.Empty;
            string empty2 = string.Empty;
            string empty3 = string.Empty;
            string str1;
            string str2;
            string str3;
            if (pInEditMode)
            {
                str1 = this.dvOrderHeaderGetTextBoxValue("tbxOrderDate");
                str2 = this.dvOrderHeaderGetTextBoxValue("tbxRoastDate");
                str3 = this.dvOrderHeaderGetTextBoxValue("tbxRequiredByDate");
                dvOrderHeaderData.Notes = this.dvOrderHeaderGetTextBoxValue("tbxNotes");
            }
            else
            {
                str3 = this.dvOrderHeaderGetLabelValue("lblRequiredByDate");
                str1 = this.dvOrderHeaderGetLabelValue("lblOrderDate");
                str2 = this.dvOrderHeaderGetLabelValue("lblRoastDate");
                dvOrderHeaderData.Notes = this.dvOrderHeaderGetLabelValue("lblNotes");
            }
            dvOrderHeaderData.RequiredByDate = string.IsNullOrEmpty(str3) ? DateTime.MinValue : Convert.ToDateTime(str3).Date;
            dvOrderHeaderData.OrderDate = string.IsNullOrEmpty(str1) ? DateTime.MinValue : Convert.ToDateTime(str1).Date;
            dvOrderHeaderData.RoastDate = string.IsNullOrEmpty(str2) ? DateTime.MinValue : Convert.ToDateTime(str2).Date;
            return dvOrderHeaderData;
        }
        protected void btnAdd_Click(object sender, EventArgs e)
        {
            OrderHeaderData headerData = this.Get_dvOrderHeaderData(false);
            OrderTblData orderData = new OrderTblData
            {
                CustomerID = headerData.CustomerID,
                OrderDate = headerData.OrderDate,
                RoastDate = headerData.RoastDate,
                RequiredByDate = headerData.RequiredByDate,
                ToBeDeliveredBy = Convert.ToInt32(headerData.ToBeDeliveredBy),
                PurchaseOrder = headerData.PurchaseOrder,
                Confirmed = headerData.Confirmed,
                InvoiceDone = headerData.InvoiceDone,
                Done = headerData.Done,
                Notes = headerData.Notes,
                ItemTypeID = Convert.ToInt32(this.cboNewItemDesc.SelectedValue),
                QuantityOrdered = Convert.ToDouble(this.tbxNewQuantityOrdered.Text),
                PackagingID = Convert.ToInt32(this.cboNewPackaging.SelectedValue)
            };

            var manager = new TrackerDotNet.Managers.OrderManager();
            string result = manager.AddOrderLine(headerData, orderData);

            this.ltrlStatus.Text = string.IsNullOrWhiteSpace(result) ? "Item Added" : "Error adding item: " + result;
            this.HideNewOrderItemPanel();
        }
        protected void btnCancel_Click(object sender, EventArgs e) => this.HideNewOrderItemPanel();

        protected void gvOrderLines_OnItemDelete(object sender, EventArgs e)
        {
            string pDataValue = ((CommandEventArgs)e).CommandArgument.ToString();
            var manager = new TrackerDotNet.Managers.OrderManager();
            string result = manager.DeleteOrderItem(Convert.ToInt32(pDataValue));
            this.ltrlStatus.Text = string.IsNullOrEmpty(result) ? "Item Deleted" : "Error deleting item: " + result;
        }
      
        protected void gvOrderLines_RowUpdated(object sender, GridViewUpdatedEventArgs e)
        {
            // Exit edit mode first
            gvOrderLines.EditIndex = -1;

            // Only update the UpdatePanel, don't force DataBind
            upnlOrderLines.Update();

            // Don't call DataBind() here - it will happen automatically
            // The ObjectDataSource will refresh the GridView after the update
        }
        protected virtual void dvOrderHeader_OnModeChanging(object sender, DetailsViewModeEventArgs e)
        {
            if (e.NewMode == DetailsViewMode.Edit)
            {
                this.Session[CONST_ORDERHEADERVALUES] = (object)this.Get_dvOrderHeaderData(false);
            }
            else
            {
                if (e.NewMode != DetailsViewMode.ReadOnly || this.Session[CONST_ORDERHEADERVALUES] == null)
                    return;
                this.dvOrderHeader.DataBind();
            }
        }

        protected virtual void dvOrderHeader_OnItemUpdated(object sender, DetailsViewUpdatedEventArgs e)
        {
            this.upnlOrderLines.Update();
        }
        /// <summary>
        /// Gets an integer value from a control by name, supporting both ComboBox and HiddenField types.
        /// </summary>
        /// <param name="row">The GridViewRow to search in</param>
        /// <param name="comboBoxControlName">The name/ID of the control to find</param>
        /// <param name="fallbackControlName">Optional fallback control name to try if first control is not found</param>
        /// <returns>The integer value from the control, or 0 if not found or invalid</returns>
        private int GetControlSelectedValue(GridViewRow row, string comboBoxControlName, string hidddenControlName)
        {
            // Try to find as ComboBox first
            var comboBox = row.FindControl(comboBoxControlName) as AjaxControlToolkit.ComboBox;
            if (comboBox != null && !string.IsNullOrEmpty(comboBox.SelectedValue))
            {
                if (int.TryParse(comboBox.SelectedValue, out int comboValue))
                    return comboValue;
            }

            // Try to find as HiddenField
            var hiddenField = row.FindControl(hidddenControlName) as HiddenField;
            if (hiddenField != null && !string.IsNullOrEmpty(hiddenField.Value))
            {
                if (int.TryParse(hiddenField.Value, out int hiddenValue))
                    return hiddenValue;
            }
            return SystemConstants.DatabaseConstants.InvalidID ; // Default value if control not found or invalid
        }
        protected virtual void dvOrderHeader_OnDataBound(object sender, EventArgs e)
        {
            if (this.dvOrderHeader.CurrentMode == DetailsViewMode.ReadOnly)
            {
                if (this.Session[CONST_ORDERHEADERVALUES] != null)
                {
                    OrderHeaderData orderHeaderData = (OrderHeaderData)this.Session[CONST_ORDERHEADERVALUES];
                    if (!this.GetOrderHeaderRequiredByDateStr().Equals(string.Empty))
                    {
                        DateTime date = Convert.ToDateTime(this.GetOrderHeaderRequiredByDateStr()).Date;
                        if (orderHeaderData.OrderDate.Date != date.Date)
                        {
                            UsedItemGroupTbl usedItemGroupTbl = new UsedItemGroupTbl();
                            foreach (GridViewRow row in this.gvOrderLines.Rows)
                            {
                                int itemTypeId = GetControlSelectedValue(row, CONST_ORDERLINE_ITEM_COMBOBOX_ID, CONST_ORDERLINE_ITEM_HIDDENFIELD_ID);
                                if (itemTypeId != 0)
                                {
                                    usedItemGroupTbl.UpdateIfGroupItem(orderHeaderData.CustomerID, itemTypeId, orderHeaderData.RequiredByDate, date);
                                }
                            }
                        }
                    }
                }
                Label control1 = (Label)this.dvOrderHeader.FindControl("lblPurchaseOrder");
                if (control1 != null && control1.Text.Equals(SystemConstants.UIConstants.PORequiredText))
                {
                    control1.BackColor = Color.Red;
                    control1.ForeColor = Color.White;
                }
            }
            CheckBox control2 = (CheckBox)this.dvOrderHeader.FindControl("cbxDone");
            if (control2 != null)
                this.btnOrderDelivered.Enabled = this.btnOrderCancelled.Enabled = !control2.Checked;
            this.updtButtonPanel.Update();
        }

        public void DeleteOrderItem(string pOrderID)
        {
            string str = new OrderTbl().DeleteOrderById(Convert.ToInt32(pOrderID));
            this.ltrlStatus.Text = str.Length == 0 ? "Item deleted" : str;
        }

        protected void btnCancelled_Click(object sender, EventArgs e)
        {
            if (!(Membership.GetUser().UserName.ToLower() == SystemConstants.UserConstants.AdminUserName))
                return;
            foreach (TableRow row in this.gvOrderLines.Rows)
                this.DeleteOrderItem(((Label)row.Cells[4].FindControl("lblOrderID")).Text);
            this.Response.Redirect("DeliverySheet.aspx");
        }
        public string GetPackagingDesc(int pPackagingID)
        {
            return pPackagingID > 0 ? new PackagingTbl().GetPackagingDesc(pPackagingID) : string.Empty;
        }
        private ContactEmailDetails GetEmailAddressFromNote()
        {
            ContactEmailDetails emailAddressFromNote = (ContactEmailDetails)null;
            string labelValue = this.dvOrderHeaderGetLabelValue("lblNotes");
            int num = labelValue.IndexOf("[#");
            if (num >= 0)
            {
                emailAddressFromNote = new ContactEmailDetails();
                emailAddressFromNote.EmailAddress = labelValue.Substring(num + 2, labelValue.IndexOf("#]") - num - 2);
            }
            return emailAddressFromNote;
        }

        private ContactEmailDetails GetEmailDetails(string pContactsID)
        {
            ContactEmailDetails contactEmailDetails = new ContactEmailDetails();
            return !pContactsID.Equals(SystemConstants.CustomerConstants.SundryCustomerIDStr) ? 
                contactEmailDetails.GetContactsEmailDetails(Convert.ToInt32(pContactsID)) : 
                this.GetEmailAddressFromNote();
        }

        private string AddUnitsToQty(string pItemTypeID, string pQty)
        {
            string itemUoM = this.GetItemUoM(Convert.ToInt32(pItemTypeID));
            if (string.IsNullOrEmpty(itemUoM))
                return pQty;
            double num = Convert.ToDouble(pQty);
            return $"{pQty} {(num == 1.0 ? itemUoM : itemUoM + "s")}";
        }

        private int GetItemSortOrderID(string pItemTypeID)
        {
            return new ItemTypeTbl().GetItemSortOrder(Convert.ToInt32(pItemTypeID));
        }

        private string UpCaseFirstLetter(string pString)
        {
            return string.IsNullOrEmpty(pString) ? string.Empty : char.ToUpper(pString[0]).ToString() + pString.Substring(1);
        }

        private string ResolveRecipientEmail(ContactEmailDetails details)
        {
            return !string.IsNullOrWhiteSpace(details.EmailAddress)
                ? details.EmailAddress
                : details.altEmailAddress;
        }
        private static (string controlId, string controlDesc) GetControlIdAndDescFromRow(GridViewRow row, string comboBoxName, string labelName, string hiddenFieldName)
        {
            // Try to get the ComboBox first (edit mode)
            var itemControl = row.FindControl(comboBoxName) as AjaxControlToolkit.ComboBox;
            if (itemControl != null && itemControl.SelectedValue != null)
            {
                string itemId = itemControl.SelectedValue;
                string itemName = itemControl.SelectedItem != null ? itemControl.SelectedItem.Text : string.Empty;
                return (itemId, itemName);
            }

            // Fallback: try to get the hidden field and label (display mode)
            var hndItemId = row.FindControl(hiddenFieldName) as HiddenField;
            var lblItemDesc = row.FindControl(labelName) as Label;
            if (hndItemId != null && !string.IsNullOrEmpty(hndItemId.Value))
            {
                string itemId = hndItemId.Value;
                string itemName = lblItemDesc != null ? lblItemDesc.Text : string.Empty;
                return (itemId, itemName);
            }

            // Not found
            return (string.Empty, string.Empty);
        }
        private void AppendOrderItemsToEmailBody(EmailMailKitCls email)
        {
            email.AddToBody("<ul>");

            foreach (GridViewRow row in gvOrderLines.Rows)
            {
                var (itemId, itemDesc) = GetControlIdAndDescFromRow(row, CONST_ORDERLINE_ITEM_COMBOBOX_ID, CONST_ORDERLINE_ITEM_HIDDENFIELD_LABEL, CONST_ORDERLINE_ITEM_HIDDENFIELD_ID);
                var qtyLbl = (Label)row.FindControl("lblQuantityOrdered");
                var (packagingId, packagingDesc) = GetControlIdAndDescFromRow(row, CONST_ORDERLINE_PACKAGING_COMBOBOX_ID, CONST_ORDERLINE_PACKAGING_HIDDENFIELD_LABEL, CONST_ORDERLINE_PACKAGING_HIDDENFIELD_ID); ;

                string qty = AddUnitsToQty(itemId, qtyLbl.Text);

                if (GetItemSortOrderID(itemId) == 10)
                {
                    string notes = EmailUtils.CleanNoteText(dvOrderHeaderGetLabelValue("lblNotes"));
                    email.AddFormatToBody("<li>{0}</li>", notes);
                }
                else
                {
                    if (packagingId.Equals("0"))
                        email.AddFormatToBody(MessageProvider.Get("OrderItemFormatBasic"), qty, itemDesc);
                    else
                        email.AddFormatToBody(MessageProvider.Get("OrderItemFormatWithPrep"), qty, itemDesc, packagingDesc);
                }
            }

            email.AddToBody("</ul>");
        }
        protected void btnConfirmOrder_Click(object sender, EventArgs e)
        {
            // Gather data from UI
            // Get ContactEmailDetails from the selected contact in the DetailsView
            var contactID = dvOrderHeaderGetCBoControlSelectedValue(CONST_ORDERHEADER_CONTACT_ID);
            ContactEmailDetails contact = GetEmailDetails(contactID);

            // Get OrderHeaderData using your existing helper
            OrderHeaderData header = this.Get_dvOrderHeaderData(false);

            //Build List<OrderLineData> from the GridView
            var orderLines = new List<TrackerDotNet.Managers.OrderLineData>();
            foreach (GridViewRow row in this.gvOrderLines.Rows)
            {
                
                var (itemId, itemDesc) = GetControlIdAndDescFromRow(row, CONST_ORDERLINE_ITEM_COMBOBOX_ID, CONST_ORDERLINE_ITEM_HIDDENFIELD_LABEL, CONST_ORDERLINE_ITEM_HIDDENFIELD_ID);
                var qtyLbl = (Label)row.FindControl("lblQuantityOrdered");
                var (packagingIdStr, packagingDesc) = GetControlIdAndDescFromRow(row, CONST_ORDERLINE_PACKAGING_COMBOBOX_ID, CONST_ORDERLINE_PACKAGING_HIDDENFIELD_LABEL, CONST_ORDERLINE_PACKAGING_HIDDENFIELD_ID);
                int packagingId = Convert.ToInt32(packagingIdStr);

                var line = new TrackerDotNet.Managers.OrderLineData
                {
                    ItemID = Convert.ToInt32(itemId),
                    ItemName = itemDesc,
                    Qty = Convert.ToDouble(qtyLbl.Text),
                    PackagingID = packagingId > 0 ? packagingId : 0,
                    PackagingName = packagingId > 0 ? packagingDesc : string.Empty
                };
                orderLines.Add(line);
            }
            
            // Get notes from the order header
            string notes = this.GetOrderHeaderNotes();

            var emailManager = new TrackerDotNet.Managers.OrderDetailManager();
            string statusMsg;
            bool success = emailManager.SendOrderConfirmation(contact, header, orderLines, notes, out statusMsg);

            ltrlStatus.Text = statusMsg;
            // Show message box, update UI, etc.
            new showMessageBox(this.Page, "Order Confirmation", statusMsg);
            upnlNewOrderItem.Update();
        }


        public string GetToBeDeliveredBy(object pToBeDeliveredBy)
        {
            return pToBeDeliveredBy != null ? pToBeDeliveredBy.ToString() : "0";
        }

        public string GetItemUoMObj(object pItemID)
        {
            return pItemID == null ? string.Empty : this.GetItemUoM(Convert.ToInt32(pItemID.ToString()));
        }

        public string GetItemUoM(int pItemID)
        {
            return pItemID > 0 ? new ItemTypeTbl().GetItemUnitOfMeasure(pItemID) : string.Empty;
        }

        protected void odsOrderSummary_OnUpdated(object sender, ObjectDataSourceStatusEventArgs e)
        {
            if ((bool)e.ReturnValue)
            {
                var control1 = (ComboBox)this.dvOrderHeader.FindControl(CONST_ORDERHEADER_CONTACT_ID);
                TextBox control2 = (TextBox)this.dvOrderHeader.FindControl("tbxRequiredByDate");
                TextBox control3 = (TextBox)this.dvOrderHeader.FindControl("tbxNotes");
                if (control1 != null && control2 != null && control3 != null)
                    this.BindRowQueryParameters();
            }
            this.gvOrderLines.DataBind();
            this.upnlOrderLines.Update();
        }
        protected void MarkItemAsInvoiced()
        {
            var manager = new TrackerDotNet.Managers.OrderManager();
            manager.MarkItemAsInvoiced(
                (long)this.Session[SystemConstants.SessionConstants.BoundCustomerID],
                ((DateTime)this.Session[SystemConstants.SessionConstants.BoundDeliveryDate]).Date,
                (string)this.Session[SystemConstants.SessionConstants.BoundNotes]);
            this.pnlOrderHeader.Update();
        }
        protected void btnOrderDelivered_Click(object sender, EventArgs e)
        {
            OrderHeaderData headerData = this.Get_dvOrderHeaderData(false);
            var orderLines = new List<OrderManager.TempOrderLineData>();
            ItemTypeTbl itemTypeTbl = new ItemTypeTbl();

            foreach (GridViewRow row in this.gvOrderLines.Rows)
            {
                
                var itemId = GetControlSelectedValue(row, CONST_ORDERLINE_ITEM_COMBOBOX_ID, CONST_ORDERLINE_ITEM_HIDDENFIELD_ID);
                var qtyLbl = (Label)row.FindControl("lblQuantityOrdered");
                var packagingId = GetControlSelectedValue(row, CONST_ORDERLINE_PACKAGING_COMBOBOX_ID, CONST_ORDERLINE_PACKAGING_HIDDENFIELD_ID);
                var orderIdLbl = (Label)row.FindControl("lblOrderID");

                var line = new OrderManager.TempOrderLineData
                {
                    ItemID = itemId,
                    Qty = Convert.ToDouble(qtyLbl.Text),
                    PackagingID = Convert.ToInt32(packagingId),
                    ServiceTypeID = itemTypeTbl.GetServiceID(itemId),
                    OriginalOrderID = Convert.ToInt32(orderIdLbl.Text)
                };
                orderLines.Add(line);
            }

            var manager = new TrackerDotNet.Managers.OrderManager();
            bool success = manager.CompleteOrderDelivery(headerData, orderLines);

            if (!success)
                this.ltrlStatus.Text = "Error deleting Temp Table";
            else
                this.Response.Redirect("OrderDone.aspx");
        }

        protected void gvOrderLines_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            // Only process DataRow types in Edit mode
            if (e.Row.RowType != DataControlRowType.DataRow)
            {
                return;
            }

            // Handle EDIT MODE ONLY - get values from ViewState
            if ((e.Row.RowState & DataControlRowState.Edit) == DataControlRowState.Edit)
            {
                int rowIndex = e.Row.RowIndex;

                // Get stored values from ViewState
                int packagingId = ViewState[$"PackagingID_{rowIndex}"] != null ? (int)ViewState[$"PackagingID_{rowIndex}"] : 0;
                int itemTypeId = ViewState[$"ItemTypeID_{rowIndex}"] != null ? (int)ViewState[$"ItemTypeID_{rowIndex}"] : 0;
                // Handle packaging ComboBox
                var cboPackaging = e.Row.FindControl("cboPackaging") as AjaxControlToolkit.ComboBox;
                if (cboPackaging != null)
                {
                    // DON'T CALL DataBind() - it causes the Bind() expression error
                    // The ComboBox should already be populated by its DataSourceID

                    // Ensure "n/a" option exists
                    if (!cboPackaging.Items.Cast<ListItem>().Any(item => item.Value == "0"))
                    {
                        cboPackaging.Items.Insert(0, new ListItem("n/a", "0"));
                    }

                    // Set the selected value safely
                    string packagingIdStr = packagingId.ToString();
                    if (cboPackaging.Items.Cast<ListItem>().Any(item => item.Value == packagingIdStr))
                    {
                        cboPackaging.SelectedValue = packagingIdStr;
                    }
                    else if (packagingId > 0)
                    {
                        // Add missing packaging option for inactive items
                        string description = GetPackagingDesc(packagingId);
                        if (!string.IsNullOrEmpty(description))
                        {
                            cboPackaging.Items.Add(new ListItem($"{description} (Inactive)", packagingIdStr));
                            cboPackaging.SelectedValue = packagingIdStr;
                        }
                        else
                        {
                            cboPackaging.SelectedValue = "0";
                        }
                    }
                    else
                    {
                        cboPackaging.SelectedValue = "0";
                    }
                }

                // Handle item ComboBox the same way
                var cboItemDesc = e.Row.FindControl("cboItemDesc") as AjaxControlToolkit.ComboBox;
                if (cboItemDesc != null)
                {
                    // DON'T CALL DataBind() - it causes the Bind() expression error
                    // The ComboBox should already be populated by its DataSourceID

                    if (!cboItemDesc.Items.Cast<ListItem>().Any(item => item.Value == "0"))
                    {
                        cboItemDesc.Items.Insert(0, new ListItem("--Invalid Item--", "0"));
                    }

                    string itemTypeIdStr = itemTypeId.ToString();
                    if (cboItemDesc.Items.Cast<ListItem>().Any(item => item.Value == itemTypeIdStr))
                    {
                        cboItemDesc.SelectedValue = itemTypeIdStr;
                    }
                    else
                    {
                        cboItemDesc.SelectedValue = "0";
                    }
                }
                // Clear ViewState after use
                ViewState.Remove($"PackagingID_{rowIndex}");
                ViewState.Remove($"ItemTypeID_{rowIndex}");
            }
        }
        protected void gvOrderLines_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            gvOrderLines.EditIndex = -1;
            gvOrderLines.DataBind();
            upnlOrderLines.Update();
        }
        protected void gvOrderLines_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            GridViewRow row = gvOrderLines.Rows[e.RowIndex];

            // Use helper method for cleaner code
            e.NewValues["ItemTypeID"] = Convert.ToInt32(GetControlSelectedValue(row, CONST_ORDERLINE_ITEM_COMBOBOX_ID, CONST_ORDERLINE_ITEM_HIDDENFIELD_ID));
            e.NewValues["PackagingID"] = Convert.ToInt32(GetControlSelectedValue(row, CONST_ORDERLINE_PACKAGING_COMBOBOX_ID, CONST_ORDERLINE_PACKAGING_HIDDENFIELD_ID));

            // Get quantity from TextBox
            var tbxQuantityOrdered = row.FindControl("tbxQuantityOrdered") as TextBox;
            if (tbxQuantityOrdered != null)
            {
                e.NewValues["QuantityOrdered"] = Convert.ToDouble(tbxQuantityOrdered.Text);
            }

            // Get OrderID - this should be set as NewValues, not Keys
            var hdnOrderID = row.FindControl("lblOrderID") as HiddenField;
            if (hdnOrderID != null)
            {
                e.NewValues["OrderID"] = Convert.ToInt64(hdnOrderID.Value);
            }

            // Debug output
            System.Diagnostics.Debug.WriteLine($"RowUpdating: OrderID = {e.NewValues["OrderID"]}, PackagingID = {e.NewValues["PackagingID"]}, ItemTypeID = {e.NewValues["ItemTypeID"]}");
        }
        protected void gvOrderLines_RowEditing(object sender, GridViewEditEventArgs e)
        {
            // Get values from hidden fields in view mode BEFORE setting edit mode
            GridViewRow row = gvOrderLines.Rows[e.NewEditIndex];

            var hdnPackagingID = row.FindControl("hdnPackagingID") as HiddenField;
            var hdnItemTypeID = row.FindControl("hdnItemTypeID") as HiddenField;

            int packagingId = 0;
            int itemTypeId = 0;

            if (hdnPackagingID != null && !string.IsNullOrEmpty(hdnPackagingID.Value))
            {
                int.TryParse(hdnPackagingID.Value, out packagingId);
            }

            if (hdnItemTypeID != null && !string.IsNullOrEmpty(hdnItemTypeID.Value))
            {
                int.TryParse(hdnItemTypeID.Value, out itemTypeId);
            }

            ViewState[$"PackagingID_{e.NewEditIndex}"] = packagingId;
            ViewState[$"ItemTypeID_{e.NewEditIndex}"] = itemTypeId;
            // Set edit mode and let the ObjectDataSource handle the binding
            gvOrderLines.EditIndex = e.NewEditIndex;

            // REMOVE THESE LINES - they cause the infinite loop!
            // odsOrderDetail.DataBind();
            // gvOrderLines.DataBind();

            upnlOrderLines.Update();
        }
        protected void btnUnDoDone_Click(object sender, EventArgs e)
        {
            var manager = new TrackerDotNet.Managers.OrderManager();
            string empty = string.Empty;
            foreach (TableRow row in this.gvOrderLines.Rows)
            {
                Label control = (Label)row.Cells[4].FindControl("lblOrderID");
                empty += manager.UnDoOrderItem(Convert.ToInt32(control.Text));
            }
            this.ltrlStatus.Text = empty;
            this.dvOrderHeader.DataBind();
            this.pnlOrderHeader.Update();
            this.gvOrderLines.DataBind();
            this.upnlOrderLines.Update();
        }
        protected void gvOrderLines_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            bool flag = false;
            if (e.CommandName == "MoveOneDayOn")
            {
                flag = true;
                Label control = (Label)this.gvOrderLines.Rows[Convert.ToInt32(e.CommandArgument)].FindControl("lblOrderID");
                DateTime pNewDate = Convert.ToDateTime(this.dvOrderHeaderGetLabelValue("lblRequiredByDate")).Date;
                if (pNewDate.DayOfWeek < DayOfWeek.Friday)
                {
                    pNewDate = pNewDate.AddDays(1.0);
                }
                else
                {
                    int num = (int)(1 - pNewDate.DayOfWeek + 7) % 7;
                    pNewDate = pNewDate.AddDays((double)num);
                }
                new OrderTbl().UpdateOrderDeliveryDate(pNewDate, Convert.ToInt32(control.Text));
            }
            else if (e.CommandName == "DeleteOrder")
            {
                flag = true;
                this.DeleteOrderItem(e.CommandArgument.ToString());
            }
            if (!flag)
                return;
            this.dvOrderHeader.DataBind();
            this.pnlOrderHeader.Update();
            this.gvOrderLines.DataBind();
            this.upnlOrderLines.Update();
        }

    }
}