using System.Web;
using Newtonsoft.Json;
using TrackerSQL.Classes;

namespace TrackerSQL.Tools
{
    public class EmailComboTest : IHttpHandler
    {
        public bool IsReusable => false;

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "application/json";
            context.Response.Cache.SetCacheability(HttpCacheability.NoCache);

            string action = context.Request["action"] ?? string.Empty;

            if (action != "start")
            {
                context.Response.StatusCode = 400;
                context.Response.Write(JsonConvert.SerializeObject(new { status = "error", message = "Unknown action." }));
                return;
            }

            var result = EmailComboTestRunner.RunAllTests(
                context.Request["smtpHost"],
                context.Request["smtpUser"],
                context.Request["smtpPass"],
                context.Request["from"],
                context.Request["to"]);

            context.Response.Write(JsonConvert.SerializeObject(result));
        }
    }
}
